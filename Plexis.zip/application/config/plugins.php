<?php
$Plugins = array(
    'Plexis'
);
?>