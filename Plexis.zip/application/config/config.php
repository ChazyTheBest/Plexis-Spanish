<?php
$site_title = 'Plexis';
$site_email = 'wilson.steven10@yahoo.com';
$site_support_email = 'support@yahoo.com';
$meta_keywords = 'Site Keywords';
$meta_description = 'Site Description';
$site_maintenance = 0;
$site_updating = 0;
$default_template = 'default';
$default_language = 'english';
$emulator = 'trinity';
$logon_server = '127.0.0.1';
$enable_gzip_output = 1;
$default_realm_id = 1;
$allow_registration = 1;
$reg_email_verification = 0;
$reg_registration_key = 0;
$reg_unique_email = 0;
$enable_captcha = 1;
$send_email_pass_change = 0;
$web_points_enabled = 1;
?>