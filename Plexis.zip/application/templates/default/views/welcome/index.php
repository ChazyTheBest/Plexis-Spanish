{news}
    <div class="left-box">
        <h2>{title}</h2>
        <div class="left-box-content">
            {body}
        </div>
        <div class="left-news-foot">
            <p style="text-align: right;">Written by: {author}, {posted}</p>
        </div>
    </div>
{/news}