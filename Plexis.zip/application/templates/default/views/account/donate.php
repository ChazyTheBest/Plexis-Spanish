<div class="left-box">
    <h2>Donate</h2>
    <div class="left-box-content">
        <div class="alert info">Under Construction</div>
    </div>
</div>
