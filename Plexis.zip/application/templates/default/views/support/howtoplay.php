<div class="left-box">
    <h2>Connection Guide</h2>
    <div class="left-box-content">
        {text}
    </div>
</div>