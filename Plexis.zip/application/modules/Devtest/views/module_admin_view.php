<div class="grid_12">
    <div class="block-border">
        <div class="block-header">
            <h1>Devtest Admin Panel Integration!</h1><span></span>
        </div>
        <div class="block-content">
            <div class="alert success">{test}</div>
        </div>
        <div class="block-content dark-bg">
            <p>&nbsp;</p>
        </div>
    </div>
</div>