<div class="left-box">
    <h2>Test Module</h2>
    <div class="left-box-content">
        It Works!
    </div>
</div>