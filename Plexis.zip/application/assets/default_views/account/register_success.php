<!-- Create Spacer -->
<div style="margin-top: 10px; text-align: center;">
	Welcome {session.user.username}! <a href='{SITE_URL}/account'>Click here to view your account</a>
</div>
