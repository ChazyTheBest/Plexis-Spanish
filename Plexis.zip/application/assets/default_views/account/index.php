<center>
	Your Username is: {session.user.username}<br />
	Your Account ID is: {session.user.id}<br /><br />
	<a href="{SITE_URL}/account/logout">Click here to log out</a>
</center>