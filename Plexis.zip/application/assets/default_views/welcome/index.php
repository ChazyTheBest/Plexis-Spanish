<ul class="news-box">
	{news}
		<li>
			<h2>{title}</h2>
			<div class="meta">
				<p>
					Posted By: <a href="#" >{author}</a> | {posted}
				</p>
			</div>
			<p>
				{body}
			</p>
		</li>
	{/news}
</ul>