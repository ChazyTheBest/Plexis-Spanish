<div class="grid_12">
    <div class="block-border">
        <div class="block-header">
            <h1>Characters</h1><span></span>
        </div>
        <div class="block-content">
            <div class="alert info">
                <strong>Information:</strong> Sorry, but there are no realms installed!
            </div>
        </div>
        <div class="block-content dark-bg">
            <p>&nbsp;</p>
        </div>
    </div>
</div>