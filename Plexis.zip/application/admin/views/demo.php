<div class="grid_12">
    <div class="block-border">
        <div class="block-header">
            <h1>Demo Mode Enabled</h1><span></span>
        </div>
        <div class="block-content">
            <div class="alert info">
                <strong>Information:</strong> Sorry, but you cant preform such an action in demo mode!
            </div>
        </div>
        <div class="block-content dark-bg">
            <p>&nbsp;</p>
        </div>
    </div>
</div>