<div class="grid_12">
    <div class="block-border">
        <div class="block-header">
            <h1>PHPinfo</h1><span></span>
        </div>
        <div class="block-content" style="height: 500px;">
            <iframe src="{SITE_URL}/admin/phpinfo/html" frameborder="0" height="100%" width="100%">Your browser does not support iFrames :(</iframe>
        </div>
        <div class="block-content dark-bg">
            <p>&nbsp;</p>
        </div>
    </div>
</div>