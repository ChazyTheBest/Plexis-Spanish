<div class="grid_12">
    <div class="block-border">
        <div class="block-header">
            <h1>Error Loading Module</h1><span></span>
        </div>
        <div class="block-content">
            <div class="alert error">
                An error was encountered while loading the module admin method. Please check your error log.
            </div>
        </div>
        <div class="block-content dark-bg">
            <p>&nbsp;</p>
        </div>
    </div>
</div>