<?php
return array(
    0 => "Name of your childhood best friend?",
    1 => "What is your mother's maiden name?",
    2 => "What is your father's middle name?",
    3 => "What was the name of your first pet?",
    4 => "What school did you go to in the 1st grade?",
    5 => "What is you favorite movie?"
);